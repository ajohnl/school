#include <string>
#include <iostream>
#include <stdio.h>


void program(){
//using namespace std;
int a, b;
std::cout << "Input sides separated by spaces please";
std::cin >> a >> b;
//std::cout << "Input side 2 please";
//std::cin >> b;
int c;
c = a * b;
std::cout << "The area is " << c << "\n";









}













int main(){program();std::cout << "Press enter to leave\n"; getchar();getchar();return 0;}













//get area based on sides
